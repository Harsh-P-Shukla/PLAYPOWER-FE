import React, { useEffect, useRef, useState, useCallback } from 'react';
import Toolbar from './components/Toolbar';
import NotesList from './components/NotesList';
import NoteEditor from './components/NoteEditor';
import { encrypt, decrypt } from './utils/encryption';
import { saveNotes, loadNotes } from './utils/storage';
import { getGrammarSuggestions } from './utils/grammar';
import { generateInsights } from './utils/insights';
import { generateId, formatDate, sanitizeHTML } from './utils/helpers';
import './styles/main.css';

function App() {
  const editorRef = useRef(null);
  const [notes, setNotes] = useState(loadNotes());
  const [activeNoteId, setActiveNoteId] = useState(notes.length ? notes[0].id : null);
  const [theme, setTheme] = useState(localStorage.getItem('theme') || 'light');
  const [passwordInput, setPasswordInput] = useState('');
  const [grammarAlerts, setGrammarAlerts] = useState([]);
  const [aiInsights, setAIInsights] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [settings, setSettings] = useState({
    fontSize: localStorage.getItem('fontSize') || '16px',
    enableGlossary: localStorage.getItem('enableGlossary') !== 'false',
    enableGrammar: localStorage.getItem('enableGrammar') !== 'false',
    enableAI: localStorage.getItem('enableAI') !== 'false',
  });

  const activeNote = notes.find(note => note.id === activeNoteId);
  const filteredNotes = notes.filter(note => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return note.title.toLowerCase().includes(query) || 
           note.content.toLowerCase().includes(query);
  });

  // Save notes whenever they change
  useEffect(() => {
    saveNotes(notes);
  }, [notes]);

  // Toggle light/dark mode
  useEffect(() => {
    document.body.className = theme;
    localStorage.setItem('theme', theme);
  }, [theme]);

  // Save settings changes
  useEffect(() => {
    Object.entries(settings).forEach(([key, value]) => {
      localStorage.setItem(key, value);
    });
  }, [settings]);

  const handleNewNote = () => {
    const newNote = {
      id: generateId(),
      title: 'Untitled Note',
      content: '',
      pinned: false,
      encrypted: false,
      tags: [],
      lastEdited: new Date().toISOString()
    };
    setNotes([newNote, ...notes]);
    setActiveNoteId(newNote.id);
  };

  const handleNoteChange = (id, content) => {
    setNotes(notes.map(note =>
      note.id === id ? { 
        ...note, 
        content: sanitizeHTML(content),
        lastEdited: new Date().toISOString()
      } : note
    ));
  };

  const handleSelectNote = (id) => {
    setActiveNoteId(id);
    setGrammarAlerts([]);
    setAIInsights([]);
  };

  const handleDeleteNote = (id) => {
    setNotes(notes.filter(note => note.id !== id));
    if (activeNoteId === id) {
      setActiveNoteId(notes.length > 1 ? notes[0].id : null);
    }
  };

  const handlePinNote = (id) => {
    setNotes(notes.map(note =>
      note.id === id ? { ...note, pinned: !note.pinned } : note
    ));
  };

  const handleEncryptNote = () => {
    if (!passwordInput) return alert('Enter password to encrypt!');
    if (!activeNote || activeNote.encrypted) return;

    const encryptedContent = encrypt(activeNote.content, passwordInput);
    setNotes(notes.map(note =>
      note.id === activeNote.id
        ? { ...note, content: encryptedContent, encrypted: true }
        : note
    ));
    alert('Note encrypted!');
    setPasswordInput('');
  };

  const handleDecryptNote = () => {
    if (!passwordInput) return alert('Enter password to decrypt!');
    if (!activeNote || !activeNote.encrypted) return;

    const decrypted = decrypt(activeNote.content, passwordInput);
    if (!decrypted) {
      alert('Decryption failed! Wrong password?');
      return;
    }

    setNotes(notes.map(note =>
      note.id === activeNote.id
        ? { ...note, content: decrypted, encrypted: false }
        : note
    ));
    alert('Note decrypted!');
    setPasswordInput('');
  };

  const runGrammarCheck = async () => {
    if (!activeNote || activeNote.encrypted || !settings.enableGrammar) return;
    try {
      const suggestions = await getGrammarSuggestions(activeNote.content);
      setGrammarAlerts(suggestions);
    } catch (error) {
      console.error('Grammar check failed:', error);
      alert('Grammar check failed. Please try again later.');
    }
  };

  const runAIInsights = () => {
    if (!activeNote || activeNote.encrypted || !settings.enableAI) return;
    try {
      const insights = generateInsights(activeNote.content);
      setAIInsights(insights);
    } catch (error) {
      console.error('AI insights failed:', error);
      alert('AI insights failed. Please try again later.');
    }
  };

  const handleExport = (content, format) => {
    if (!content) return;
    
    const blob = new Blob([content], { type: format === 'pdf' ? 'application/pdf' : 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `note-${formatDate(new Date())}.${format}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleSearch = (query) => {
    setSearchQuery(query);
  };

  const handleSettingsChange = (key, value) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className={`app loaded ${theme}`}>
      <div className="sidebar">
        <div className="sidebar-header">
          <button className="new-note-btn" onClick={handleNewNote}>+ New Note</button>
          <button
            className="theme-toggle"
            onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
          >
            {theme === 'light' ? '🌙' : '☀️'}
          </button>
        </div>

        <div className="search-bar">
          <input
            type="text"
            placeholder="Search notes..."
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
          />
        </div>

        <div className="notes-list">
          <NotesList
            notes={filteredNotes}
            activeNoteId={activeNoteId}
            onSelect={handleSelectNote}
            onDelete={handleDeleteNote}
            onPin={handlePinNote}
          />
        </div>

        <div className="settings-panel">
          <h3>Settings</h3>
          <div className="setting-item">
            <label>Font Size:</label>
            <select
              value={settings.fontSize}
              onChange={(e) => handleSettingsChange('fontSize', e.target.value)}
            >
              <option value="14px">Small</option>
              <option value="16px">Medium</option>
              <option value="18px">Large</option>
            </select>
          </div>
          <div className="setting-item">
            <label>
              <input
                type="checkbox"
                checked={settings.enableGlossary}
                onChange={(e) => handleSettingsChange('enableGlossary', e.target.checked)}
              />
              Enable Glossary
            </label>
          </div>
          <div className="setting-item">
            <label>
              <input
                type="checkbox"
                checked={settings.enableGrammar}
                onChange={(e) => handleSettingsChange('enableGrammar', e.target.checked)}
              />
              Enable Grammar Check
            </label>
          </div>
          <div className="setting-item">
            <label>
              <input
                type="checkbox"
                checked={settings.enableAI}
                onChange={(e) => handleSettingsChange('enableAI', e.target.checked)}
              />
              Enable AI Insights
            </label>
          </div>
        </div>
      </div>

      <div className="editor-section">
        {activeNote && (
          <>
            <Toolbar
              editorRef={editorRef}
              onExport={handleExport}
              onSearch={handleSearch}
            />
            <NoteEditor
              note={activeNote}
              onChange={handleNoteChange}
              editorRef={editorRef}
            />

            <div className="editor-actions">
              <input
                type="password"
                placeholder="Enter password"
                value={passwordInput}
                onChange={e => setPasswordInput(e.target.value)}
              />
              {!activeNote.encrypted ? (
                <button onClick={handleEncryptNote}>🔒 Lock</button>
              ) : (
                <button onClick={handleDecryptNote}>🔓 Unlock</button>
              )}
              {settings.enableGrammar && (
                <button onClick={runGrammarCheck}>📝 Grammar</button>
              )}
              {settings.enableAI && (
                <button onClick={runAIInsights}>💡 AI Insight</button>
              )}
            </div>

            {grammarAlerts.length > 0 && (
              <div className="grammar-alerts">
                <strong>Grammar Suggestions:</strong>
                <ul>
                  {grammarAlerts.map((item, idx) => (
                    <li key={idx}>{item.message} → "{item.replacement}"</li>
                  ))}
                </ul>
              </div>
            )}

            {aiInsights.length > 0 && (
              <div className="ai-panel">
                <strong>Insights:</strong>
                <ul>
                  {aiInsights.map((insight, idx) => (
                    <li key={idx}>{insight}</li>
                  ))}
                </ul>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

export default App;
