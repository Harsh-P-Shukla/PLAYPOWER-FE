import React from 'react';
import { formatDate, truncateText } from '../utils/helpers';

function NotesList({ notes, activeNoteId, onSelect, onDelete, onPin }) {
  // Sort notes: pinned first, then by last edited
  const sortedNotes = [...notes].sort((a, b) => {
    if (a.pinned !== b.pinned) return b.pinned ? 1 : -1;
    return new Date(b.lastEdited) - new Date(a.lastEdited);
  });

  return (
    <div className="notes-list">
      {sortedNotes.map(note => (
        <div
          key={note.id}
          className={`note-item ${note.id === activeNoteId ? 'active' : ''} ${note.pinned ? 'pinned' : ''}`}
          onClick={() => onSelect(note.id)}
        >
          <div className="note-content">
            <div className="note-header">
              <h3 className="note-title text-truncate">{note.title || 'Untitled Note'}</h3>
              <div className="note-actions">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onPin(note.id);
                  }}
                  title={note.pinned ? 'Unpin' : 'Pin'}
                >
                  {note.pinned ? '📌' : '📍'}
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete(note.id);
                  }}
                  title="Delete"
                >
                  🗑️
                </button>
              </div>
            </div>
            
            <div className="note-preview text-truncate">
              {truncateText(note.content.replace(/<[^>]*>/g, ''), 100)}
            </div>
            
            <div className="note-meta">
              <span className="note-date">
                {formatDate(new Date(note.lastEdited))}
              </span>
              {note.tags && note.tags.length > 0 && (
                <div className="note-tags">
                  {note.tags.map(tag => (
                    <span key={tag} className="note-tag">
                      #{tag}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default NotesList;
