import React from 'react';
import { formatDate } from '../utils/helpers';

function Toolbar({ editorRef, onExport, onSearch }) {
  const executeCommand = (command, value = null) => {
    document.execCommand(command, false, value);
    editorRef.current?.focus();
  };

  const handleExport = (format) => {
    if (!editorRef.current) return;
    const content = editorRef.current.innerHTML;
    onExport(content, format);
  };

  return (
    <div className="toolbar">
      <div className="formatting-tools">
        <button onClick={() => executeCommand('bold')} title="Bold">
          <strong>B</strong>
        </button>
        <button onClick={() => executeCommand('italic')} title="Italic">
          <em>I</em>
        </button>
        <button onClick={() => executeCommand('underline')} title="Underline">
          <u>U</u>
        </button>
        <button onClick={() => executeCommand('strikeThrough')} title="Strike">
          <s>S</s>
        </button>
        <select onChange={(e) => executeCommand('formatBlock', e.target.value)}>
          <option value="p">Paragraph</option>
          <option value="h1">Heading 1</option>
          <option value="h2">Heading 2</option>
          <option value="h3">Heading 3</option>
        </select>
        <button onClick={() => executeCommand('insertUnorderedList')} title="Bullet List">
          • List
        </button>
        <button onClick={() => executeCommand('insertOrderedList')} title="Numbered List">
          1. List
        </button>
        <button onClick={() => executeCommand('createLink', prompt('Enter URL:'))} title="Link">
          🔗
        </button>
        <button onClick={() => executeCommand('justifyLeft')} title="Align Left">
          ←
        </button>
        <button onClick={() => executeCommand('justifyCenter')} title="Align Center">
          ↔
        </button>
        <button onClick={() => executeCommand('justifyRight')} title="Align Right">
          →
        </button>
      </div>

      <div className="export-tools">
        <button onClick={() => handleExport('pdf')} title="Export as PDF">
          📄 PDF
        </button>
        <button onClick={() => handleExport('txt')} title="Export as Text">
          📝 TXT
        </button>
      </div>

      <div className="search-tool">
        <input
          type="text"
          placeholder="Search notes..."
          onChange={(e) => onSearch(e.target.value)}
        />
      </div>

      <div className="last-edited">
        Last edited: {formatDate(new Date())}
      </div>
    </div>
  );
}

export default Toolbar;
